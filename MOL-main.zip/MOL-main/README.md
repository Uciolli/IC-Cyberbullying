# MOL
Multilingual Offensive Lexicon
